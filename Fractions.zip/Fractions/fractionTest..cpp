#include <iostream>
#include <iomanip>
#include <fstream>
#include "fraction.h"

using namespace std;

int main()
{
    fraction g(2, -3);
    fraction p(-6, -4);
    fraction s = g.add(p);
    //cout << g.getNumer() << " / " << g.getDenom();
    cout << s.getNumer() << '/';
    cout << s.getDenom();
    return 0;
}
