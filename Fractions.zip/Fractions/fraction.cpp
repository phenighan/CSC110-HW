#include <iostream>
#include <fstream>
#include <iomanip>
#include "fraction.h"

//constructor with two default parameters
fraction::fraction (int n, int d)
{
    numerator = n;
    denominator = d;
}
//destructor not used for now
fraction::~fraction()
{
}
//get numerator
int fraction::getNumer()
{
    return numerator;
}
//get denominator
int fraction::getDenom()
{
    return denominator;
}
//add function
fraction fraction::add(fraction a)
{
    int num1 =  numerator * a.denominator; //numerator to this fraction
    int num2 = a.numerator * denominator; //numerator to other fraction
    int denom = denominator * a.denominator; //denominator
    fraction result(num1 + num2, denom); //local object
    return result;
}
