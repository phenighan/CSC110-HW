#include <iostream>
#include <fstream>
#include <iomanip>
#include "fraction.h"

//constructor with two default parameters
fraction::fraction (int n, int d)
{
    numerator = n;
    denominator = d;
}
//destructor not used for now
fraction::~fraction()
{
}
//get numerator
int fraction::getNumer()
{
    return numerator;
}
//get denominator
int fraction::getDenom()
{
    return denominator;
}
//add function
fraction fraction::add(fraction a)
{
    int num1 =  numerator * a.denominator; //numerator to this fraction
    int num2 = a.numerator * denominator; //numerator to other fraction
    int denom = denominator * a.denominator; //denominator
    fraction result(num1 + num2, denom); //local object
    return result;
}
//used to reduce fractions
int fraction::gcf(int n, int d) //use Euler's gcf algorithm
{
    int resGCF;  //declaration of result
    int remainder = 0; //initialize remainder
    while (d !=0) //loops until denominator is zero
    {
        remainder = n%d; //remainder of n/d
        n = d; //assign denominator to numerator
        d = remainder; //assign remainder to denominator
    }
    resGCF = n; //assign numerator to result
    return resGCF; //return result GCF
}
