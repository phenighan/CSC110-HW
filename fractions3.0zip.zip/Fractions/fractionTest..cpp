/*Paris Henighan
22JAN2017
Version 3.0
Fractions Program
This program performs various arithmetic problems associated with fractions.
It also converts from decimal to fraction and fraction to decimal. */
//include all associated and used libraries
#include <iostream>
#include <iomanip>
#include <fstream>
#include "fraction.h"

using namespace std;
//declare input and output files
ifstream fin ("fractionIn.txt");
ofstream fout ("fractionOut.txt");
void header(); //declare function for header file

int main()
{
    header(); //display the header
    int numerator1, denominator1, numerator2, denominator2, wholeNumber1, wholeNumber2; //declare variables
    double deci; //declare variables
    int DataSet = 1; //declare and set data set variable to keep up with which data set is being displayed
    //priming read
    fin >> numerator1 >> denominator1 >> numerator2 >> denominator2 >> deci >> wholeNumber1 >> wholeNumber2;
    while (!fin.eof()) //loops while data is in file
    {
        cout<< "         Data Set" << DataSet << "   Fraction 1    Fraction 2      Solution" <<endl;
        cout<< "        ----------   ----------    ----------      --------" << endl<<endl;
        fraction Fraction1(numerator1, denominator1);
        fraction Fraction2(numerator2, denominator2);
        cout<<setw(18);
        cout<< "Addition:";
        cout<<setw(3)<<' ';
        Fraction1.print();
        cout<<setw(4);
        cout <<" + ";
        Fraction2.print();
        cout << "  = ";
        fraction AddFraction = Fraction1.add(Fraction2);
        cout<<setw(20);
        AddFraction.print();
        cout << endl<<endl;
        cout<<setw(21);
        cout<<"Subtraction:   ";
        Fraction1.print();
        cout<<setw(4);
        cout<<" - ";
        Fraction2.print();
        cout<<"  = ";
        fraction SubtractFraction = Fraction1.subtract(Fraction2);
        SubtractFraction.print();
        cout<< endl<<endl;
        cout<<setw(21);
        cout <<"Multiplication:   ";
        Fraction1.print();
        cout<<"  * ";
        Fraction2.print();
        cout<<"  = ";
        fraction MultiplyFraction = Fraction1.multiply(Fraction2);
        MultiplyFraction.print();
        cout<< endl<<endl;
        cout<<setw(21);
        cout<<"Division:   ";
        Fraction1.print();
        cout<<"  / ";
        Fraction2.print();
        cout<<"  = ";
        fraction DivideFraction = Fraction1.divide(Fraction2);
        DivideFraction.print();
        cout<< endl<<endl;
        cout<<setw(21);
        cout<<"Inverse:   ";
        Fraction1.print();
        cout<<"                = ";
        fraction Inverse1fraction = Fraction1.getInverse();
        Inverse1fraction.print();
        cout<<endl<<endl;
        cout<<setw(21);
        cout<<"Inverse:   ";
        cout<<setw(14)<<' ';
        Fraction2.print();
        cout<<"  = ";
        fraction Inverse2fraction = Fraction2.getInverse();
        Inverse2fraction.print();
        cout<< endl<<endl;
        cout<<setw(18);
        cout<<"Equiv. fraction 1:";
        cout<<setw(3)<<' ';
        Fraction1.print();
        cout<<setw(17) <<"=";
        cout<<setw(2)<<' ';
        Fraction1.getDecimal();
        cout<< endl;
        cout<<setw(18);
        cout<<"Equiv. fraction 2:";
        cout<<setw(17)<<' ';
        Fraction2.print();
        cout<<setw(5);
        cout<<"=  ";
        Fraction2.getDecimal();
        cout<<endl;
        cout<<setw(18);
        cout<<"Improper fraction:";
        cout<<setw(13)<< wholeNumber1 << " and";
        Fraction1.print();
        fraction Improper1Fraction = Fraction1.makeImproperFraction(wholeNumber1,Fraction1);
        cout<<"  = ";
        Improper1Fraction.print();
        cout<<endl<<endl;
        cout<<setw(18);
        cout<<"Improper fraction:";
        cout<<setw(13)<< wholeNumber2 << " and";
        Fraction2.print();
        fraction Improper2Fraction = Fraction2.makeImproperFraction(wholeNumber2,Fraction2);
        cout<<"  = ";
        Improper2Fraction.print();
        cout<< endl<<endl;
        cout<<setw(18);
        cout<<"Deci. to Fraction:";
        cout<<setw(27)<<deci;
        cout<<setw(4)<<"= ";
        fraction MakeFraction = Fraction2.makeFraction(deci);
        MakeFraction.print();
        cout<<endl<<endl<<endl;
        fin >> numerator1 >> denominator1 >> numerator2 >> denominator2 >> deci >> wholeNumber1 >> wholeNumber2; //read in all files
        DataSet = DataSet +1; //data set increment
    }
    //close input and output files and end program
    fin.close();
    fout.close();
    return 0;
}
//header file
void header()
{
    cout<< "                F R A C T I O N   O P E R A T I O N S" <<endl;
    cout<< "                -------------------------------------" << endl <<endl;
    cout <<"                       Written by Jeff Goldstein      "<< endl <<endl;
}
