#include <iostream>
#include <iomanip>
#include <fstream>
#include "fraction.h"

using namespace std;

ifstream fin ("fractionIn.txt");
ofstream fout ("fractionOut.txt");

int main()
{
    int numerator1, denominator1, numerator2, denominator2, wholeNumber1, wholeNumber2;
    double deci;
    //priming read
    fin >> numerator1 >> denominator1 >> numerator2 >> denominator2 >> deci >> wholeNumber1 >> wholeNumber2;
    while (!fin.eof()) //loops while data is in file
    {
        fraction Fraction1(numerator1, denominator1);
        fraction Fraction2(numerator2, denominator2);

        Fraction1.print();
        cout << endl;
        Fraction2.print();
        cout << endl;
        Fraction1.print(fout);
        cout << endl;
        Fraction2.print(fout);
        cout << endl;

        fraction AddFraction = Fraction1.add(Fraction2);
        fraction SubtractFraction = Fraction1.subtract(Fraction2);
        fraction MultiplyFraction = Fraction1.multiply(Fraction2);
        fraction DivideFraction = Fraction1.divide(Fraction2);
        fraction Inverse1fraction = Fraction1.getInverse();
        fraction Inverse2fraction = Fraction2.getInverse();
        //Fraction1.getDecimal();
        //Fraction2.getDecimal();
        fraction Improper2Fraction = Fraction2.makeImproperFraction(wholeNumber2,Fraction2);
        fraction Improper1Fraction = Fraction1.makeImproperFraction(wholeNumber1,Fraction1);
        fraction MakeFraction = Fraction2.makeFraction(deci);
        Improper1Fraction.print();
        cout << endl;
        Improper1Fraction.print(fout);
        cout << endl;
        cout << "=====================" << endl << endl;
        fout << "=====================" << endl << endl;
        fin >> numerator1 >> denominator1 >> numerator2 >> denominator2 >> deci >> wholeNumber1 >> wholeNumber2;
    }
    fin.close();
    fout.close();
    return 0;
}
