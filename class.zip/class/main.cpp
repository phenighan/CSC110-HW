/*#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    int a = -7;
    int b = 10;
    double c = 3.0/4;
    cout << "12345678901234567890" << endl;
    cout << setw(4) << a << '/' << setw(4) << b << endl;
    cout << setprecision(6) << fixed;
    cout << setw(12) << c << endl;

    return 0;
}
*/
//Program: Static and automatic variables
#include <iostream>

using namespace std;

void test();

int main()
{
    int count;

    for (count = 1; count <= 5; count++)
        test();

    return 0;
}

void test()
{
    static int x = 0;
    int y = 10;

    x = x + 2;
    y = y + 1;

    cout << "Inside test x = " << x << " and y = "
         << y << endl;
}
